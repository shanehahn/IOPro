echo "init/main.c"
diff init/main.c 		../change_for_aiopro/nexus6_aiopro/init/main.c
echo "fs/aiopro.c"
diff fs/aiopro.c 		../change_for_aiopro/nexus6_aiopro/fs/aiopro.c
echo "fs/read_write.c"
diff fs/read_write.c 		../change_for_aiopro/nexus6_aiopro/fs/read_write.c
echo "fs/sync.c"
diff fs/sync.c 			../change_for_aiopro/nexus6_aiopro/fs/sync.c
echo "fs/direct-io.c"
diff fs/direct-io.c 		../change_for_aiopro/nexus6_aiopro/fs/direct-io.c
echo "fs/internal.h"
diff fs/internal.h 		../change_for_aiopro/nexus6_aiopro/fs/internal.h
echo "fs/Makefile"
diff fs/Makefile 		../change_for_aiopro/nexus6_aiopro/fs/Makefile
#echo "fs/ext4/file.c"
#diff fs/ext4/file.c		../change_for_aiopro/nexus6_aiopro/fs/ext4/file.c
echo "mm/filemap.c"
diff mm/filemap.c 		../change_for_aiopro/nexus6_aiopro/mm/filemap.c
echo "block/blk-core.c"
diff block/blk-core.c 		../change_for_aiopro/nexus6_aiopro/block/blk-core.c
echo "drivers/scsi/scsi.c"
diff drivers/scsi/scsi.c 	../change_for_aiopro/nexus6_aiopro/drivers/scsi/scsi.c
echo "drivers/mmc/core/core.c"
diff drivers/mmc/core/core.c 	../change_for_aiopro/nexus6_aiopro/drivers/mmc/core/core.c
echo "drivers/mmc/core/core.c"
diff drivers/mmc/card/block.c 	../change_for_aiopro/nexus6_aiopro/drivers/mmc/card/block.c
echo "fs.h"
diff include/linux/fs.h 	../change_for_aiopro/nexus6_aiopro/include/linux/fs.h
echo "blk_type.h"
diff include/linux/blk_types.h 	../change_for_aiopro/nexus6_aiopro/include/linux/blk_types.h
