#!/bin/bash
make ARCH=arm SUBARCH=arm CROSS_COMPILE=./arm-eabi-4.8/bin/arm-eabi- shamu_defconfig
